# UltimateKEYS CE - Latest (experimental)

Testing of UltimateKEYS CE (Compact Edition)

This slimmed-down version does not have any dead keys on the layout, offering a more simplified approach.

**Keyboard Layout Image&nbsp;:**

![UltimateKEYS CE - Keyboard Layout Image](UltimateKEYS%20CE%20-%20Keyboard%20Layout%20Image.png)
